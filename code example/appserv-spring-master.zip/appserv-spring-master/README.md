# appserv-spring

Code examples used in the Network Programming (ID1212) course at KTH. This repository contains the code example used in the section on application servers with Spring Web MVC. The example is a very simple bank application, where it is possible to create and search for accounts, and to deposit and withdraw money.
